# -*- coding: utf-8 -*-
"""
Created on Sun May 25 11:05:16 2025

@author: sileshih
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

def perform_eda(df):
 
    os.makedirs('C:/Users/sileshih/Downloads/Capstone project/ethiopia_health_analytics/outputs/plots', exist_ok=True)
    plt.figure(figsize=(12, 8))
    for metric in df.columns[2:]:
        plt.figure()
        sns.lineplot(data=df, x='date', y=metric, hue='country') 
        plt.title(f'{metric} Trends (2015-2023)')
        plt.xticks(rotation=45)
        plt.tight_layout()
        
        plt.savefig(f'C:/Users/sileshih/Downloads/Capstone project/ethiopia_health_analytics/outputs/plots/{metric.replace(" ", "_")}_trend.png')
        plt.close()

    eth_df = df[df['country'] == 'Ethiopia'].drop(columns=['country']) 
    eth_df_numeric = eth_df.drop(columns=['date'])
    corr_matrix = eth_df_numeric.corr(numeric_only=True) 
    plt.figure(figsize=(10, 8))
    sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', fmt=".2f")
    plt.title('Ethiopia Health Indicators Correlation')
    plt.savefig(f'C:/Users/sileshih/Downloads/Capstone project/ethiopia_health_analytics/outputs/plots/ethiopia_correlation.png')
    plt.close()

    df['date'] = df['date'].astype(int) 
    for year in range(2015, 2023):
        year_df = df[df['date'] == year] 
        for metric in df.columns[2:]:
            plt.figure()
            sns.barplot(data=year_df, x='country', y=metric) 
            plt.title(f'{metric} Comparison ({year})')
            plt.xticks(rotation=45)
            plt.tight_layout()
            plt.savefig(f'C:/Users/sileshih/Downloads/Capstone project/ethiopia_health_analytics/outputs/plots/{metric.replace(" ", "_")}_{year}_comparison.png')
            plt.close()

if __name__ == "__main__":
    print("Performing EDA...")
    df = pd.read_csv('C:/Users/sileshih/Downloads/Capstone project/ethiopia_health_analytics/data/processed/cleaned_health_data.csv')
    perform_eda(df)
    print("EDA visualizations saved to outputs/plots/")
