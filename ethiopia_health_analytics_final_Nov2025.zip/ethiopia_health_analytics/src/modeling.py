# -*- coding: utf-8 -*-
"""
Created on Tue May 27 19:32:43 2025

@author: sileshih
"""

import pandas as pd
import numpy as np
from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_absolute_error, mean_squared_error
import matplotlib.pyplot as plt
import os

def forecast_health_indicators(df):
    os.makedirs('C:/Users/sileshih/Downloads/Capstone project/ethiopia_health_analytics/outputs/models', exist_ok=True)

    eth_df = df[df['country'] == 'Ethiopia'].sort_values('date')
    results = {}

    for metric in eth_df.columns[2:]:
        series = eth_df[metric].values
        train_size = int(len(series) * 0.8)
        train, test = series[:train_size], series[train_size:]

        # ARIMA model
        model = ARIMA(train, order=(1,1,1))
        model_fit = model.fit()

        # Evaluate
        predictions = model_fit.forecast(steps=len(test))
        mae = mean_absolute_error(test, predictions)
        rmse = np.sqrt(mean_squared_error(test, predictions))

        # Forecast next 5 years
        full_model = ARIMA(series, order=(1,1,1))
        full_fit = full_model.fit()
        forecast = full_fit.forecast(steps=5)

        # Plot results
        plt.figure(figsize=(12, 6))
        plt.plot(eth_df['date'], series, 'b-', label='Historical')
        
        last_year = int(eth_df['date'].iloc[-1])
        future_years = list(range(last_year + 1, last_year + 6))
        plt.plot(future_years, forecast, 'r--', label='Forecast')
        plt.title(f'{metric} Forecast for Ethiopia')
        plt.xlabel('Year')
        plt.ylabel(metric)
        plt.legend()
        plt.grid(True)
        plt.savefig(f'C:/Users/sileshih/Downloads/Capstone project/ethiopia_health_analytics/outputs/models/{metric.replace(" ", "_")}_forecast.png')
        plt.close()

        results[metric] = {
            'model': full_fit,
            'mae': mae,
            'rmse': rmse,
            'forecast': forecast,
            'forecast_years': future_years
        }

    return results


if __name__ == "__main__":
    print("Training forecasting models...")
    df = pd.read_csv('C:/Users/sileshih/Downloads/Capstone project/ethiopia_health_analytics/data/processed/cleaned_health_data.csv')
    results = forecast_health_indicators(df)
    
    forecast_df = pd.DataFrame({
        'Year': results[list(results.keys())[0]]['forecast_years'],
        **{metric: results[metric]['forecast'] for metric in results}
    })
    forecast_df.to_csv('C:/Users/sileshih/Downloads/Capstone project/ethiopia_health_analytics/outputs/models/health_forecasts.csv', index=False)
    print("Forecast results saved to outputs/models/health_forecasts.csv")
