# -*- coding: utf-8 -*-
"""
Created on Fri Jun 06 20:20:27 2025

@author: sileshih
"""

import dash
from dash import dcc, html, Input, Output
import plotly.express as px
import pandas as pd
import os

df = pd.read_csv('C:/Users/sileshih/Downloads/Capstone project/ethiopia_health_analytics/data/processed/cleaned_health_data.csv')
forecast_df = pd.read_csv('C:/Users/sileshih/Downloads/Capstone project/ethiopia_health_analytics/outputs/models/health_forecasts.csv')

df = df.rename(columns={'date': 'Year'})
forecast_df['country'] = 'Ethiopia'
df_long = pd.melt(df, id_vars=['Year', 'country'], var_name='Metric', value_name='Value')
df_long['Type'] = 'Actual'
forecast_df_long = pd.melt(forecast_df, id_vars=['Year', 'country'], var_name='Metric', value_name='Value')
forecast_df_long['Type'] = 'Forecast'
combined_df_long = pd.concat([df_long, forecast_df_long])

app = dash.Dash(__name__)
app.layout = html.Div([
    html.H1("Ethiopia Health Indicators Dashboard", style={'textAlign': 'center'}),

    dcc.Tabs([
        # Tab 1: Country Comparison
        dcc.Tab(label='Country Comparison', children=[
            html.Div([
                dcc.Dropdown(
                    id='metric-selector',
                    options=[{'label': col, 'value': col}
                             for col in df.columns if col not in ['Year', 'country']],
                    value='Antiretroviral therapy coverage (% of people living with HIV)',
                    style={'width': '50%'}
                ),
                dcc.Dropdown(
                    id='year-selector',
                    options=[{'label': year, 'value': year}
                             for year in sorted(df['Year'].unique(), reverse=True)],
                    value=2023,
                    style={'width': '50%'}
                ),
            ], style={'padding': 20}),
            dcc.Graph(id='comparison-chart')
        ]),

        # Tab 2: Time Series Analysis
        dcc.Tab(label='Time Series Analysis', children=[
            html.Div([
                dcc.Dropdown(
                    id='country-selector',
                    options=[{'label': country, 'value': country}
                             for country in df['country'].unique()],
                    value='Ethiopia',
                    multi=True,
                    style={'width': '50%'}
                ),
                dcc.Dropdown(
                    id='metric-selector-ts',
                    options=[{'label': col, 'value': col}
                             for col in df.columns if col not in ['Year', 'country']],
                    value='Antiretroviral therapy coverage (% of people living with HIV)',
                    style={'width': '50%'}
                ),
            ], style={'padding': 20}),
            dcc.Graph(id='time-series-chart')
        ]),

        # Tab 3: Forecasts
        dcc.Tab(label='Forecasts', children=[
            html.Div([
                dcc.Dropdown(
                    id='forecast-selector',
                    options=[{'label': col, 'value': col}
                             for col in forecast_df.columns if col not in ['Year', 'country']], 
                    value='Antiretroviral therapy coverage (% of people living with HIV)',
                    style={'width': '50%'}
                ),
            ], style={'padding': 20}),
            dcc.Graph(id='forecast-chart')
        ])
    ])
])

@app.callback(
    Output('comparison-chart', 'figure'),
    [Input('metric-selector', 'value'),
     Input('year-selector', 'value')]
)
def update_comparison(metric, year):
    filtered_df = df[df['Year'] == year]
    fig = px.bar(
        filtered_df,
        x='country', 
        y=metric,
        title=f'{metric} by Country ({year})',
        color='country' 
    )
    return fig

@app.callback(
    Output('time-series-chart', 'figure'),
    [Input('country-selector', 'value'),
     Input('metric-selector-ts', 'value')]
)
def update_time_series(countries, metric):
    if not isinstance(countries, list):
        countries = [countries]

    filtered_df = df[df['country'].isin(countries)] 
    fig = px.line(
        filtered_df,
        x='Year',
        y=metric,
        color='country', 
        title=f'{metric} Trend',
        markers=True
    )
    fig.update_layout(xaxis_title='Year', yaxis_title=metric)
    return fig

@app.callback(
    Output('forecast-chart', 'figure'),
    [Input('forecast-selector', 'value')]
)
def update_forecast(metric):
    plot_df = combined_df_long[(combined_df_long['Metric'] == metric) & (combined_df_long['country'] == 'Ethiopia')]

    fig = px.line(
        plot_df,
        x='Year',
        y='Value', 
        color='Type',
        title=f'{metric} Forecast for Ethiopia',
        markers=True,
        line_dash='Type'
    )
    fig.update_layout(xaxis_title='Year', yaxis_title=metric)
    return fig

if __name__ == '__main__':
    app.run(debug=True, port=8080) 
