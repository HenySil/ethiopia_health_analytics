# -*- coding: utf-8 -*-
"""
Created on Sat May 17 13:17:15 2025

@author: sileshih
"""
import wbdata as wb
import pandas as pd
import os 

# Health indicators list
indicators = {
    'SH.HIV.ARTC.ZS' : 'Antiretroviral therapy coverage (% of people living with HIV)',
    'SH.HIV.PMTC.ZS' : 'Antiretroviral therapy coverage for PMTCT (% of pregnant women living with HIV)',
    'SH.STA.BRTC.ZS' : 'Births attended by skilled health staff (% of total)',
    'SH.XPD.KHEX.GD.ZS' : 'Capital health expenditure (% of GDP)',
    'SP.DYN.CONU.AL.ZS' : 'Contraceptive prevalence, any method (% of all women ages 15-49)',
    'SP.DYN.CONM.AL.ZS' : 'Contraceptive prevalence, any modern method (% of all women ages 15-49)',
    'SH.XPD.CHEX.GD.ZS' : 'Current health expenditure (% of GDP)',
    'SP.DYN.CDRT.IN' : 'Death rate, crude (per 1,000 people)',
    'SH.STA.DIAB.ZS' : 'Diabetes prevalence (% of population ages 20 to 79)',
    'SP.DYN.TFRT.IN' : 'Fertility rate, total (births per woman)',
    'SH.MED.BEDS.ZS' : 'Hospital beds (per 1,000 people)',
    'SH.IMM.IBCG' : 'Immunization, BCG (% of one-year-old children)',
    'SH.IMM.HEPB' : 'Immunization, HepB3 (% of one-year-old children)',
    'SH.IMM.MEAS' : 'Immunization, measles (% of children ages 12-23 months)',
    'SH.IMM.IDPT' : 'Immunization, DPT (% of children ages 12-23 months)',
    'SH.IMM.HIB3' : 'Immunization, Hib3 (% of children ages 12-23 months)',
    'SH.IMM.MEA2' : 'Immunization, measles second dose (% of children by the nationally recommended age)',
    'SH.IMM.POL3' : 'Immunization, Pol3 (% of one-year-old children)',
    'SH.HIV.INCD.TL.P3' : 'Incidence of HIV, all (per 1,000 uninfected population)',
    'SH.TBS.INCD' : 'Incidence of tuberculosis (per 100,000 people)',
    'SH.MLR.INCD.P3' : 'Incidence of malaria (per 1,000 population at risk)',
    'SP.DYN.LE00.IN' : 'Life expectancy at birth, total (years)',
    'SH.STA.TRAF.P5' : 'Mortality caused by road traffic injury (per 100,000 people)',
    'SH.STA.MMRT.NE' : 'Maternal mortality ratio (national estimate, per 100,000 live births)',
    'SH.STA.TRAF.FE.P5' : 'Mortality caused by road traffic injury, female (per 100,000 female population)',
    'SH.DYN.NCOM.ZS' : 'Mortality from CVD, cancer, diabetes or CRD between exact ages 30 and 70 (%)',
    'SP.DYN.IMRT.IN' : 'Mortality rate, infant (per 1,000 live births)',
    'SH.DYN.NMRT' : 'Mortality rate, neonatal (per 1,000 live births)',
    'SH.DYN.MORT' : 'Mortality rate, under-5 (per 1,000)',
    'SH.STA.PNVC.ZS' : 'Postnatal care coverage (% mothers)',
    'SH.STA.ANVC.ZS' : 'Pregnant women receiving prenatal care (%)',
    'SH.DYN.AIDS.ZS' : 'Prevalence of HIV, total (% of population ages 15-49)',
    'SH.HTN.PREV.ZS' : 'Prevalence of hypertension (% of adults ages 30-79)',
    'SH.TBS.MORT' : 'Tuberculosis death rate (per 100,000 people)'

}

# comparable countries
countries = ['ETH', 'KEN', 'TZA', 'UGA', 'RWA', 'SDN']

def fetch_wb_data():
    dfs = []
    for code, name in indicators.items():
        df = wb.get_dataframe(
            indicators={code: name},
            country=countries,
            date=("2015", "2023")
        )
        dfs.append(df)

    full_df = pd.concat(dfs, axis=1)
    full_df.index.name = 'Year'
    return full_df.reset_index()

if __name__ == "__main__":
    print("Fetching World Bank data...")
    df = fetch_wb_data()
    df.to_csv('C:/Users/sileshih/Downloads/Capstone project/ethiopia_health_analytics/data/raw/health_indicators.csv', index=False)
    print("Data saved to data/raw/health_indicators.csv")
