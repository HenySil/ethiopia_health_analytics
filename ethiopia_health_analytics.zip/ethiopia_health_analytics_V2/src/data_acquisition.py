# -*- coding: utf-8 -*-
"""
Created on Sat May 17 13:17:15 2025

@author: sileshih
"""
import wbdata as wb
import pandas as pd
import os # Import the os module

# Health indicators list
indicators = {
    'SH.DYN.MORT': 'Under-5 mortality rate',
    'SP.DYN.LE00.IN': 'Life expectancy',
    'SH.XPD.CHEX.GD.ZS': 'Health expenditure (% of GDP)',
    'SH.IMM.IDPT': 'DPT immunization',
    'SH.STA.MALN.ZS': 'Undernourishment prevalence'
}

# comparable countries
countries = ['ETH', 'KEN', 'TZA', 'UGA', 'RWA', 'SDN']

def fetch_wb_data():
    dfs = []
    for code, name in indicators.items():
        df = wb.get_dataframe(
            indicators={code: name},
            country=countries,
            date=("2015", "2024")
        )
        dfs.append(df)

    full_df = pd.concat(dfs, axis=1)
    full_df.index.name = 'Year'
    return full_df.reset_index()

if __name__ == "__main__":
    print("Fetching World Bank data...")
    df = fetch_wb_data()
    df.to_csv('C:/Users/sileshih/Downloads/Capstone project/ethiopia_health_analytics/data/raw/health_indicators.csv', index=False)
    print("Data saved to data/raw/health_indicators.csv")
