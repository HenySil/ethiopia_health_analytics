# -*- coding: utf-8 -*-
"""
Created on Sat May 17 15:18:14 2025

@author: sileshih
"""

import pandas as pd
import numpy as np
from sklearn.impute import KNNImputer
import os

def clean_data(df):
    df.columns = df.columns.str.strip()
    id_vars = ['date', 'country']
    value_vars = [col for col in df.columns if col not in id_vars]
    long_df = pd.melt(df, id_vars=id_vars, value_vars=value_vars,
                     var_name='Metric', value_name='Value') 

    if 'country' in long_df.columns and 'Metric' in long_df.columns:
        clean_df = long_df.pivot_table(
            index=['date', 'country'], 
            columns='Metric',
            values='Value'
        ).reset_index()
    else:
        print("Error: 'country' or 'Metric' column not found before pivoting.")
        print("Columns in long_df:", long_df.columns)
        return None

    numeric_cols = clean_df.select_dtypes(include=np.number).columns
    imputer = KNNImputer(n_neighbors=2)
    clean_df[numeric_cols] = imputer.fit_transform(clean_df[numeric_cols])

    return clean_df

if __name__ == "__main__":
    print("Cleaning World Bank data...")
    raw_df = pd.read_csv('C:/Users/sileshih/Downloads/Capstone project/ethiopia_health_analytics/data/raw/health_indicators.csv')
    cleaned_df = clean_data(raw_df)
    cleaned_df.to_csv('C:/Users/sileshih/Downloads/Capstone project/ethiopia_health_analytics/data/processed/cleaned_health_data.csv', index=False)
    print("Cleaned data saved to data/processed/cleaned_health_data.csv")
